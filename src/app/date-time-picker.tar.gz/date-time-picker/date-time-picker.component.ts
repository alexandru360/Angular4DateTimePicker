import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {DateTimeInClass, TimerClass, KeyValue, DateOutClass} from './date-time-class';
import {isNullOrUndefined} from "util";
import * as moment from 'moment';

@Component({
  selector: 'app-date-time-picker',
  templateUrl: './date-time-picker.component.html',
  styleUrls: ['./date-time-picker.component.css'],
  providers: []
})

export class DateTimePickerComponent implements OnInit {

  @Input() inCalendar: DateTimeInClass;
  @Output() outCalendar: EventEmitter<DateOutClass> = new EventEmitter<DateOutClass>();

  nOrderIndex: number = 0;
  nOrderIndexReverse: number = 0; // for previous days!
  controlId: string = this.getId("cal");
  controlCalendarButtonId: string = this.getId("btn");
  setTimer: TimerClass = new TimerClass();

  inputId: string = this.getId('inputDate');
  currentDate: Date = (isNullOrUndefined(this.inCalendar)) ? new Date() : this.inCalendar.calendar.calendarDate;
  currentMonth: KeyValue = new KeyValue();
  currentYear: KeyValue = new KeyValue();
  displayTop: number = 0;
  displayLeft: number = 0;
  activeDayId: string = "";
  _firstEnter: boolean = true;
  masterDateTimeDiv: boolean = false;

  datepickerDays: boolean = true;
  datepickerMonths: boolean = true;
  datepickerYears: boolean = true;

  dateRow: Array<Array<PrintHtmlDate>>;
  monthRow: Array<Array<KeyValue>>;
  yearRow: Array<Array<KeyValue>>;

  public calendarTextDate = '';
  public calendarMask = [/\d/, /\d/, '.', /\d/, /\d/, '.', /\d/, /\d/, /\d/, /\d/];

  constructor() {
  }

  ngOnInit() {
    this.setMonth();
    this.setYear();

    this.dateRow = this.getDatesRows();
    this.calendarTextDate = this.getStringDateFromDate(this.inCalendar.calendar.calendarDate);
    this.monthRow = this.getMonths();
    this.yearRow = this.getYears(this.currentYear.key);
  }

  getMonths(): Array<Array<KeyValue>> {
    let oRet = new Array<Array<KeyValue>>();
    if (this.inCalendar.calendar.months.length === 12) {
      let oRow = new Array<KeyValue>();
      let j = 0;
      for (let i = 0; i < this.inCalendar.calendar.months.length; i++) {
        let kv = new KeyValue();
        kv.value = this.inCalendar.calendar.months[i];
        kv.key = i;
        oRow.push(kv);
        j = j + 1;
        if (j === 3) {
          oRet.push(oRow);
          oRow = new Array<KeyValue>();
          j = 0;
        }
      }
    } else
      oRet = this.monthRow;

    return oRet;
  }

  getYears(parYear: number) {
    // Populates a matrics 3x4 with years
    let yr = parYear;
    let oRet = new Array<Array<KeyValue>>();
    let oRow = new Array<KeyValue>();
    let j = 0;
    for (let i = 0; i < 12; i++) {
      let kv = new KeyValue();
      let newYear = yr + i;
      kv.value = String(newYear);
      kv.key = newYear;
      oRow.push(kv);
      j = j + 1;
      if (j === 3) {
        oRet.push(oRow);
        oRow = new Array<KeyValue>();
        j = 0;
      }
    }

    return oRet;
  }

  setMonth() {
    this.currentMonth.key = Number(this.currentDate.getMonth());
    this.currentMonth.value = this.inCalendar.calendar.months[this.currentMonth.key];
  }

  setYear() {
    let year = new KeyValue();
    year.key = this.currentDate.getFullYear();
    year.value = String(this.currentDate.getFullYear());
    this.currentYear = year;
  }

  getDayTodayCss(parCol: PrintHtmlDate) {
    let oRet: boolean = false;
    let today = moment(new Date()).format('YYYY.MM.DD');
    let todayFromHtml = moment(new Date(parCol.dateDate)).clone().startOf('day').format('YYYY.MM.DD');
    if (todayFromHtml === today) {
      oRet = true;
      // Also we select the day if is the first time we enter this controll.
      if (this._firstEnter) {
        this.activeDayId = parCol.id;
        this._firstEnter = false;
      }
    }

    return oRet;
  }

  getDayOutMonth(parCol: PrintHtmlDate): boolean {
    let oRet: boolean = false;
    if (parCol.dayType === DayType.OutMonth)
      oRet = true;
    return oRet;
  }

  getActiveIndicator(parCol: PrintHtmlDate) {
    let tdId = parCol.id;
    if (this.activeDayId === tdId)
      return true;
    else
      return false;
  }

  getDateIndexNo(parFlag: number = 1): number {
    if (parFlag === 1) {
      this.nOrderIndex = this.nOrderIndex + 1;
      return this.nOrderIndex;
    } else if (parFlag === 0)
      this.nOrderIndex = 0;
    else if (parFlag === 2) {
      //reverse index for previous months !
      this.nOrderIndexReverse = this.nOrderIndexReverse - 1;
      return this.nOrderIndexReverse;
    }
  }

  onCalendarClick(event) {
    // let target = event.target || event.srcElement || event.currentTarget;
    // let oCtl = target.parentElement.parentElement;
    let domInputLeft = document.getElementById(this.inputId);

    this.masterDateTimeDiv = !this.masterDateTimeDiv;
    this.inCalendar.showCalendar = !this.inCalendar.showCalendar;
    this.displayTop = event.clientY + 14;
    // this.displayLeft = event.clientX;
    this.displayLeft = domInputLeft.getBoundingClientRect().left + 1;
    this.setShowHideDateTimePicker(0);
  }

  getDatesRows(): Array<Array<PrintHtmlDate>> {
    const oRet = new Array<Array<PrintHtmlDate>>();
    //===================== settings
    //Set the [this.currentDate] before you call this method !
    // this.currentDate = this.inCalendar.calendar.calendarDate;
    if (moment(this.currentDate).isValid()) {
      let maxDays = moment(this.currentDate).daysInMonth();
      //set mask
      this.calendarMask = this.inCalendar.calendarMaskFormat;
      //===========================================

      let oRowDays0: Array<PrintHtmlDate> = new Array<PrintHtmlDate>();
      let oRowDays1: Array<PrintHtmlDate> = new Array<PrintHtmlDate>();
      let oRowDays2: Array<PrintHtmlDate> = new Array<PrintHtmlDate>();
      let oRowDays3: Array<PrintHtmlDate> = new Array<PrintHtmlDate>();
      let oRowDays4: Array<PrintHtmlDate> = new Array<PrintHtmlDate>();
      let oRowDays5: Array<PrintHtmlDate> = new Array<PrintHtmlDate>();

      let dDate: Date = new Date();
      let backDate: Date = new Date();
      let backMonthDaysIndicator: boolean = false; //Indicates if we added the days from previous month on the first line!
      let frontDate: Date = new Date();
      let day: number;
      let dayName: string;
      let backDayName: string;
      let frontDayName: string;
      let j = 0;
      let afterStepLastDateProcessed: Date;

      try {
        for (let i = 1; i <= maxDays; i++) {
          let firstDayOfMonth = new Date(Number(this.currentYear.key), Number(this.currentMonth.key), 1);
          dDate = new Date(Number(this.currentYear.key), Number(this.currentMonth.key), i);
          day = dDate.getDay();
          dayName = this.getDayName(day);
          switch (j) {
            case 0:
              if (!(day === 0) && !backMonthDaysIndicator && !(dDate.getDate() > 1)) {
                let topLimit = day;
                let scopeDay = -1;
                let scopeDate: Date;
                //Adding dais before the month !
                for (let d = topLimit; d > 0; d--) {
                  backDate = new Date(dDate.setDate(dDate.getDate() - 1));
                  scopeDay = backDate.getDay();
                  backDayName = this.getDayName(scopeDay);
                  scopeDate = new Date(
                    String(backDate.getFullYear()
                      + "-"
                      + String(backDate.getMonth() + 1 < 10 ? "0" + String(backDate.getMonth() + 1) : backDate.getMonth() + 1)
                      + "-"
                      + (backDate.getDate() < 10 ? "0" + String(backDate.getDate()) : backDate.getDate())));
                  oRowDays0.push(this.createHtmlDate(new Date(backDate), backDayName, scopeDay, DayType.OutMonth, 2));
                  if (scopeDay === 0) {
                    d = -1;
                    topLimit = -1;
                    backMonthDaysIndicator = true;
                  }
                }//Adding deys before this month - END

                //We revert to the first date of the month !
                dDate = new Date(firstDayOfMonth);
              }
              oRowDays0.push(this.createHtmlDate(dDate, dayName, day, DayType.InMonth));
              if (oRowDays0.length === 7) {
                // Sort days on line before pushing to master array
                oRowDays0 = this.sortObjectDate(oRowDays0);
                oRet.push(oRowDays0); // pushing the line to master array
                j = 1;
              }
              break;
            case 1:
              oRowDays1.push(this.createHtmlDate(new Date(dDate), dayName, day, DayType.InMonth));
              if (oRowDays1.length === 7) {
                // Sort days on line before pushing to master array
                oRowDays1 = this.sortObjectDate(oRowDays1);

                oRet.push(oRowDays1); // pushing the line to master array
                j = 2;
              }
              break;
            case 2:
              oRowDays2.push(this.createHtmlDate(new Date(dDate), dayName, day, DayType.InMonth));
              if (oRowDays2.length === 7) {
                // Sort days on line before pushing to master array
                oRowDays2 = this.sortObjectDate(oRowDays2);
                oRet.push(oRowDays2); // pushing the line to master array
                j = 3;
              }
              break;
            case 3:
              oRowDays3.push(this.createHtmlDate(new Date(dDate), dayName, day, DayType.InMonth));
              if (oRowDays3.length === 7) {
                // Sort days on line before pushing to master array
                oRowDays3 = this.sortObjectDate(oRowDays3);
                oRet.push(oRowDays3); // pushing the line to master array
                j = 4;
              }
              break;
            case 4:
              oRowDays4.push(this.createHtmlDate(new Date(dDate), dayName, day, DayType.InMonth));
              if (!(oRowDays4.length === 7) && i === maxDays) {
                //aici tre sa facem trecerea la cealalta luna !
                let topLimit = 7;
                let scopeDay = -1;
                let scopeDate: Date;
                for (let d = oRowDays4.length; d < topLimit; d++) {
                  frontDate = new Date(dDate.setDate(dDate.getDate() + 1));
                  scopeDay = backDate.getDay();
                  frontDayName = this.getDayName(scopeDay);
                  scopeDate = new Date(
                    String(backDate.getFullYear()
                      + "-"
                      + String(frontDate.getMonth() + 1 < 10 ? "0" + String(frontDate.getMonth() + 1) : frontDate.getMonth() + 1)
                      + "-"
                      + (frontDate.getDate() < 10 ? "0" + String(frontDate.getDate()) : frontDate.getDate())));
                  oRowDays4.push(this.createHtmlDate(new Date(frontDate), dayName, day, DayType.OutMonth));
                  // Setting the last day of oDate after for finish
                  afterStepLastDateProcessed = new Date(frontDate);
                }// Adding days before this month - END
                // Sort days on line before pushing to master array
                oRowDays4 = this.sortObjectDate(oRowDays4);
                oRet.push(oRowDays4); // pushing the line to master array
              } else if (oRowDays4.length === 7) {
                // Sort days on line before pushing to master array
                oRowDays4 = this.sortObjectDate(oRowDays4);
                oRet.push(oRowDays4); // pushing the line to master array
                j = 5;
              }
              break;
            case 5:
              oRowDays5.push(this.createHtmlDate(new Date(dDate), dayName, day, DayType.InMonth));
              //If we are here we are expecting a month to end in this iteration
              if (i === maxDays) {
                //aici tre sa facem trecerea la cealalta luna !
                let topLimit = 7;
                let scopeDay = -1;
                let scopeDate: Date;
                for (let d = oRowDays5.length; d < topLimit; d++) {
                  frontDate = new Date(dDate.setDate(dDate.getDate() + 1));
                  scopeDay = backDate.getDay();
                  frontDayName = this.getDayName(scopeDay);
                  scopeDate = new Date(
                    String(backDate.getFullYear()
                      + "-"
                      + String(frontDate.getMonth() + 1 < 10 ? "0" + String(frontDate.getMonth() + 1) : frontDate.getMonth() + 1)
                      + "-"
                      + (frontDate.getDate() < 10 ? "0" + String(frontDate.getDate()) : frontDate.getDate())));
                  oRowDays5.push(this.createHtmlDate(new Date(frontDate), dayName, day, DayType.OutMonth));
                  // Setting the last day of oDate after for finish
                  afterStepLastDateProcessed = new Date(frontDate);
                }// Adding days before this month - END
                // Sort days on line before pushing to master array
                oRowDays5 = this.sortObjectDate(oRowDays5);
                oRet.push(oRowDays5); // pushing the line to master array
              }
              break;
          }
        }
        if (isNullOrUndefined(afterStepLastDateProcessed))
          afterStepLastDateProcessed = new Date(dDate);
        if (!(oRowDays5.length === 7)) {
          let scopeDay = -1;
          let scopeDate: Date;
          for (let k = 1; k < 8; k++) {
            frontDate = new Date(afterStepLastDateProcessed.setDate(afterStepLastDateProcessed.getDate() + 1));
            scopeDay = backDate.getDay();
            frontDayName = this.getDayName(scopeDay);
            scopeDate = new Date(
              String(backDate.getFullYear()
                + "-"
                + String(frontDate.getMonth() + 1 < 10 ? "0" + String(frontDate.getMonth() + 1) : frontDate.getMonth() + 1)
                + "-"
                + (frontDate.getDate() < 10 ? "0" + String(frontDate.getDate()) : frontDate.getDate())));
            oRowDays5.push(this.createHtmlDate(frontDate, frontDayName, scopeDay, DayType.OutMonth));
          }
          oRet.push(oRowDays5); // pushing the line to master array
        }
      } catch (err) {
        console.error(err);
      }
    }
    this.getDateIndexNo(0); //reset day counter
    return oRet;
  }

  createHtmlDate(dDate: Date, dayName: string, day: number, dayType: DayType, indexType: number = 1): PrintHtmlDate {
    let oDate = new PrintHtmlDate();
    oDate.dateDay = String(dDate.getDate());
    oDate.dateDate = dDate;
    oDate.dayName = dayName;
    oDate.indexNo = day;
    oDate.dayType = dayType;
    oDate.id = this.getId("day");
    oDate.zOrder = this.getDateIndexNo(indexType);
    return oDate;
  }

  getId(parName: string): string {
    return parName + String((Math.random() * 1000000000000)).split('.')[0];
  }

  // getIdFromTarget(event): string {
  //   let target = event.target || event.srcElement || event.currentTarget;
  //   return target.attributes.id.nodeValue;
  // }

  getStringDateFromDate(parDate: Date): string {
    return moment(new Date(parDate)).format(this.inCalendar.calendarFormat);
  }

  sortObjectDate(oDate: Array<PrintHtmlDate>): Array<PrintHtmlDate> {
    return oDate.sort((obj1: PrintHtmlDate, obj2: PrintHtmlDate) => {
      if (obj1.zOrder > obj2.zOrder)
        return 1;
      if (obj1.zOrder < obj2.zOrder)
        return -1;
      return 0;
    });
  }

  getDayName(parDay: number): string {
    if (isNullOrUndefined(parDay))
      return null;
    if (!(parDay > 6 || parDay >= 0))
      return null;
    const weekday = new Array(7);
    weekday[0] = "Su";
    weekday[1] = "Mo";
    weekday[2] = "Tu";
    weekday[3] = "We";
    weekday[4] = "Th";
    weekday[5] = "Fr";
    weekday[6] = "Sa";

    return weekday[parDay];
  }

  dayClick(event, parCol: PrintHtmlDate) {
    let stringDate =
      parCol.dateDate.getDate() + " " +
      this.inCalendar.calendar.months[parCol.dateDate.getMonth()].substring(0,3) + " " +
      parCol.dateDate.getFullYear() + " " +
      (this.inCalendar.time.hour < 10 ? "0" + this.inCalendar.time.hour : this.inCalendar.time.hour) + ":" +
      (this.inCalendar.time.minutes < 10 ? "0" + this.inCalendar.time.minutes : this.inCalendar.time.minutes) + ":00 " +
      this.inCalendar.time.ampm.value.toUpperCase();
      let oDate = new DateOutClass();
    oDate.outDate = new Date(moment(new Date(stringDate)).locale('en').toDate());
    this.calendarTextDate = this.getStringDateFromDate(oDate.outDate);
    this.activeDayId = parCol.id;
    this.updateCalendarStatus(oDate);

    this.masterDateTimeDiv = !this.masterDateTimeDiv;
    this.inCalendar.showCalendar = !this.inCalendar.showCalendar;
  }

  updateCalendarStatus(par: DateOutClass) {
    this.outCalendar.emit(par);
  }

  //days click ================================================
  clickMonthNext() {
    this.currentDate = new Date(moment(this.currentDate).add(1, 'M').toDate());
    this.setMonth();
    this.setYear();
    this.dateRow = this.getDatesRows();
  }

  clickMonthPrevious() {
    this.currentDate = new Date(moment(this.currentDate).subtract(1, 'M').toDate());
    this.setMonth();
    this.setYear();
    this.dateRow = this.getDatesRows();
  }

  selectDay() {
    this.setShowHideDateTimePicker(0);
  }

  //days click ================================================

  //month click ================================================
  clickMonth(parIndex: number) {
    let date = new Date(moment(this.currentDate).toDate());
    let year = date.getFullYear();
    let newDate = new Date(year, parIndex, 1);
    this.currentDate = newDate;
    this.setMonth();
    this.dateRow = this.getDatesRows();
    this.selectDay();
  }

  clickYearNext(parYear: number) {
    this.currentYear = this.setYearKeyVal(parYear + 1);
    this.currentDate = new Date(this.currentYear.key, this.currentMonth.key, 1);
    this.dateRow = this.getDatesRows();
  }

  clickYearPrevious(parYear: number) {
    this.currentYear = this.setYearKeyVal(parYear - 1);
    this.currentDate = new Date(this.currentYear.key, this.currentMonth.key, 1);
    this.dateRow = this.getDatesRows();
  }

  selectMonth() {
    this.setShowHideDateTimePicker(1);
  }

  //month click ================================================

  //year click =================================================
  clickYear(parYear: number) {
    this.currentYear = this.setYearKeyVal(parYear);
    this.currentDate = new Date(this.currentYear.key, this.currentMonth.key, 1);
    this.dateRow = this.getDatesRows();
    this.selectDay();
  }

  clickYearPrevBatch() {
    //create a previous batch based on the current year !
    let getStartYear = Number(this.yearRow["0"]["0"].key);
    this.yearRow = this.getYears(getStartYear - 12);
  }

  clickYearNextBatch() {
    // create next batch based on the current year (current year the one selected in button headder is allways first element in the matrix)
    let getStartYear = Number(this.yearRow["3"]["2"].key);
    this.yearRow = this.getYears(getStartYear);
  }

  selectYear() {
    this.yearRow = this.getYears(this.currentYear.key);
    this.setShowHideDateTimePicker(2);
  }

  //year click =================================================

  //timer =================================================
  clickUpHour(parInt: number) {
    this.inCalendar.time.hour = this.inCalendar.time.increaseDecreaseHours(parInt);
  }

  clickUpMins(parInt: number) {
    this.inCalendar.time.minutes = this.inCalendar.time.increaseDecreaseMinutes(parInt);
  }

  clickShowTimer() {
    this.inCalendar.showCalendar = !this.inCalendar.showCalendar;
    this.inCalendar.time.showTimer = !this.inCalendar.time.showTimer;
  }

  //timer =================================================

  setYearKeyVal(parYear: number): KeyValue {
    let yr = new KeyValue();
    yr.key = parYear;
    yr.value = String(yr.key);
    return yr;
  }

  setShowHideDateTimePicker(parSwitch: number) {
    switch (parSwitch) {
      case(0):
        this.datepickerDays = true;
        this.datepickerMonths = false;
        this.datepickerYears = false;
        break;
      case(1):
        this.datepickerDays = false;
        this.datepickerMonths = true;
        this.datepickerYears = false;
        break;
      case(2):
        this.datepickerDays = false;
        this.datepickerMonths = false;
        this.datepickerYears = true;
        break;
    }
  }
}

class PrintHtmlDate {
  public id: string;
  public dateDay: string;
  public dateDate: Date;
  public indexNo: number; // pozition in the constant matrix [0->6]
  public dayType: DayType;
  public dayName: string;
  public zOrder: number;
}

enum DayType {
  InMonth = 1,
  OutMonth
}
