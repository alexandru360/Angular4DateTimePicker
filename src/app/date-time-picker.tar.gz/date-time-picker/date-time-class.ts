export class DateTimeInClass {
  enableTime: boolean = false;
  showCalendar: boolean = false;
  public calendarMaskFormat: any = [/\d/, /\d/, '.', /\d/, /\d/, '.', /\d/, /\d/, /\d/, /\d/,
    /\d/, /\d/, ':', /\d/, /\d/,  'AM'];
  public calendarFormat: string = "DD.MM.YYYY h:mm a";
  public calendar: CalendarClass = new CalendarClass();
  public time: TimerClass = new TimerClass();
}

export class DateOutClass {
  outDate: Date;
}

export class KeyValue {
  public key: number;
  public value: string;
}

export class CalendarClass {
  private today = new Date();

  public calendarDate: Date = new Date(); //selected day and everything from the calendar.

  public days: Array<string> = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
  public firstDayOfWeek = 0; //It can only be 0->6(corresponding to standard days listed above in the array)
  public months: Array<string> = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'];
  public listedMonth = 0; //It can only be 0->11(corresponding to standard months listed above in the array)
  public year: number = this.today.getFullYear();

  constructor() {
  }
}

export class TimerClass {
  showTimer: boolean;

  hour: number = 12;
  minutes: number = 0;
  ampm: KeyValue; //key - 0 --> AM; key - 1 --> PM

  constructor() {
    this.showTimer = false;
    this.ampm = this.setAmPm(0);
  }

  setAmPm(parIndex: number): KeyValue {
    let newAmPm = new KeyValue();
    switch (parIndex) {
      case 0:
        newAmPm.key = 0;
        newAmPm.value = 'AM';
        break;
      case 1:
        newAmPm.key = 1;
        newAmPm.value = 'PM';
        break;
    }
    return newAmPm;
  }

  changeAmPm() {
    if (this.ampm.key === 0)
      this.ampm = this.setAmPm(1);
    else
      this.ampm = this.setAmPm(0);
  }

  increaseDecreaseMinutes(parOpIdx: number): number {
    let mins = this.minutes;
    switch (parOpIdx) {
      case 0: //increase
        mins = mins + 1;
        if (this.validateMinutes(mins))
          this.minutes = mins;
        break;
      case 1: //decrease
        mins = mins - 1;
        if (this.validateMinutes(mins))
          this.minutes = mins;
        break;
    }
    return this.minutes;
  }

  increaseDecreaseHours(parOpIdx: number): number {
    let hr = this.hour;
    switch (parOpIdx) {
      case 0: //increase
        hr = hr + 1;
        if (this.validateHours(hr))
          this.hour = hr;
        break;
      case 1: //decrease
        hr = hr - 1;
        if (this.validateHours(hr))
          this.hour = hr;
        break;
    }
    return this.hour;
  }

  validateMinutes(parMinutes: number): boolean {
    return (parMinutes >= 0 && parMinutes <= 60);
  }

  validateHours(parHour: number): boolean {
    return (parHour >= 0 && parHour <= 12);
  }
}
